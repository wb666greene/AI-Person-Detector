#!/usr/bin/env python3
#
## forked from:  https://github.com/PINTO0309/TPU-Posenet
#

import platform
global __WIN__
if platform.system()[:3] != 'Lin':
    __WIN__ = True
else:
    __WIN__ = False

# Get python major version for
import sys
if sys.version_info.major < 3:
    print("Python version 3 is required.  Exiting ...")
    quit()

import argparse
import numpy as np
import cv2
import time
from PIL import Image
from time import sleep
from edgetpu.basic import edgetpu_utils
from pose_engine import PoseEngine

global save
global ofile

lastresults = None
processes = []
frameBuffer = None
results = None
fps = ""
detectfps = ""
framecount = 0
detectframecount = 0
time1 = 0
time2 = 0

EDGES = (
    ('nose', 'left eye'),
    ('nose', 'right eye'),
    ('nose', 'left ear'),
    ('nose', 'right ear'),
    ('left ear', 'left eye'),
    ('right ear', 'right eye'),
    ('left eye', 'right eye'),
    ('left shoulder', 'right shoulder'),
    ('left shoulder', 'left elbow'),
    ('left shoulder', 'left hip'),
    ('right shoulder', 'right elbow'),
    ('right shoulder', 'right hip'),
    ('left elbow', 'left wrist'),
    ('right elbow', 'right wrist'),
    ('left hip', 'right hip'),
    ('left hip', 'left knee'),
    ('right hip', 'right knee'),
    ('left knee', 'left ankle'),
    ('right knee', 'right ankle'),
)


def draw_pose(img, pose, i, threshold=0.2):
    xys = {}
    for label, keypoint in pose.keypoints.items():
        if keypoint.score < threshold: continue
        xys[label] = (int(keypoint.yx[1]), int(keypoint.yx[0]))
        img = cv2.circle(img, (int(keypoint.yx[1]), int(keypoint.yx[0])), 5, (0, 255, 0), -1)
##        print( i, label, keypoint.yx[1], keypoint.yx[0])
        if save:
            print( i, label, keypoint.yx[1], keypoint.yx[0], file=ofile)
    for a, b in EDGES:
        if a not in xys or b not in xys: continue
        ax, ay = xys[a]
        bx, by = xys[b]
        img = cv2.line(img, (ax, ay), (bx, by), (0, 255, 255), 2)

def overlay_on_image(frames, result, model_width, model_height, frameNum):

    color_image = frames

    if isinstance(result, type(None)):
        return color_image
    img_cp = color_image.copy()
    i = 0
    Npose=len(result)
##    print("Frame: "+str(frameNum)+"  N poses: "+str(Npose))
    if save:
        print("",file=ofile)
        print("Frame: "+str(frameNum)+"  N poses: "+str(Npose), file=ofile)
    for pose in result:
        draw_pose(img_cp, pose, i)
        i+=1

    cv2.putText(img_cp, fps,       (model_width-170,15), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (38,0,255), 1, cv2.LINE_AA)
    cv2.putText(img_cp, detectfps, (model_width-170,30), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (38,0,255), 1, cv2.LINE_AA)

    return img_cp


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
#    parser.add_argument("--model", default="models/posenet_mobilenet_v1_075_481_641_quant_decoder_edgetpu.tflite", help="Path of the detection model.")
#    parser.add_argument("--model", default="models/posenet_mobilenet_v1_075_721_1281_quant_decoder_edgetpu.tflite", help="Path of the detection model.")
    parser.add_argument('--res', help='Resolution', default='1280x720',
                        choices=['480x360', '640x480', '1280x720'])
    parser.add_argument("--usbcamno", type=int, default=0, help="USB Camera number.")
    parser.add_argument('--videofile', default="", help='Path to input video file. (Default="")')
    parser.add_argument("--save", action="store_true", help="save output to video file: inputFile_posenet.mp4")
    parser.add_argument('--usbfps', type=int, default=30, help='FPS of USB camera. (Default=30)')
    args = parser.parse_args()

    #model     = args.model
    default_model = 'models/posenet_mobilenet_v1_075_%d_%d_quant_decoder_edgetpu.tflite'
    if args.res == '480x360':
        camera_width  = 640
        camera_height = 480
        model_width   = 480
        model_height  = 352
        model = default_model % (353, 481)
    elif args.res == '640x480':
        camera_width  = 640
        camera_height = 480
        model_width   = 640
        model_height  = 480
        model = default_model % (481, 641)
    elif args.res == '1280x720':
        camera_width  = 1280
        camera_height = 720
        model_width   = 1280
        model_height  = 720
        model = default_model % (721, 1281)

    usbcamno  = args.usbcamno
    usbfps    = args.usbfps
    videofile = args.videofile
    save      = args.save
    waittime = 1

    devices = edgetpu_utils.ListEdgeTpuPaths(edgetpu_utils.EDGE_TPU_STATE_UNASSIGNED)
    engine = PoseEngine(model, devices[0])

    if videofile == "":
        print("[INFO] opening USB camera...")
        cam = cv2.VideoCapture(usbcamno)
        cam.set(cv2.CAP_PROP_FPS, usbfps)
        cam.set(cv2.CAP_PROP_FRAME_WIDTH, camera_width)
        cam.set(cv2.CAP_PROP_FRAME_HEIGHT, camera_height)
        window_name = "USB Camera"
    else:
        print("[INFO] opening specified video input file...") 
        cam = cv2.VideoCapture(videofile)
        window_name = "Movie File"
    vidfps = cam.get(cv2.CAP_PROP_FPS)   # ocv 3.2 or newer this is supposed to work with webcams as well
    print("[INFO] Framerate = " + str(vidfps))
    if save:
        # Define the codec and create VideoWriter object
        print("[INFO] creating output video file...")
        if __WIN__ == True:
            # Win 10 X264 & mp4 makes outputs ~20X larger than they should be, with this only ~4X larger
            # This might be safest choice for Windows
            ##fourcc = cv2.VideoWriter_fourcc(*'XVID')
            ##vidout = cv2.VideoWriter(videofile + "_posenet" + ".avi", fourcc, vidfps, (camera_width,camera_height), True)
            # But if you don't want AVI container, basically same output file sizes
            fourcc = cv2.VideoWriter_fourcc(*'mp4v')
            vidout = cv2.VideoWriter(videofile + "_posenet" + ".mp4", fourcc, vidfps, (camera_width,camera_height), True)
            # putting openh264-1.8.0-win64.dll in posenet folder and using this gets ~5X larger than it should be!
            #fourcc = cv2.VideoWriter_fourcc(*'avc1')
            #vidout = cv2.VideoWriter(videofile + "_posenet" + ".mp4", fourcc, vidfps, (camera_width,camera_height), True)
        else:
            #fourcc = cv2.VideoWriter_fourcc(*'X264')    # fourcc mapping seems buggy, use direct code value
            #vidout = cv2.VideoWriter(videofile + "_posenet" + ".mp4", fourcc, vidfps, (camera_width,camera_height), True)
            vidout = cv2.VideoWriter(videofile + "_posenet" + ".mp4", 0x00000021, vidfps, (camera_width,camera_height), True)
        ofileName=videofile + "_posenet" + ".txt"
        ofile=open(ofileName,'w')
        print("[INFO] Framerate = " + str(vidfps), file=ofile)
    cv2.namedWindow(window_name, cv2.WINDOW_AUTOSIZE)
    frameNum=0
    while True:
        t1 = time.perf_counter()

        ret, color_image = cam.read()
        if not cam.isOpened() or not ret:
                break
        if color_image is None:
            continue

        # Run inference.
        color_image = cv2.resize(color_image, (model_width, model_height))
        prepimg = color_image[:, :, ::-1].copy()
        prepimg = color_image.copy()
        tinf = time.perf_counter()
        res, inference_time = engine.DetectPosesInImage(prepimg)

        if res:
            detectframecount += 1
            imdraw = overlay_on_image(color_image, res, model_width, model_height, frameNum)
        else:
            imdraw = color_image

        cv2.imshow(window_name, imdraw)
        if save:
            vidout.write(imdraw)
        frameNum+=1
        if cv2.waitKey(waittime)&0xFF == ord('q'):
##        if cv2.waitKey(0)&0xFF == ord('q'):
            break

        # FPS calculation
        framecount += 1
        if framecount >= 15:
            fps       = "(Playback) {:.1f} FPS".format(time1/15)
            detectfps = "(Detection) {:.1f} FPS".format(detectframecount/time2)
            framecount = 0
            detectframecount = 0
            time1 = 0
            time2 = 0
        t2 = time.perf_counter()
        elapsedTime = t2-t1
        time1 += 1/elapsedTime
        time2 += elapsedTime
        
    # clean-up for exit
    cam.release()   
    if save:
        vidout.release()
        ofile.close()
    cv2.destroyAllWindows()
    

